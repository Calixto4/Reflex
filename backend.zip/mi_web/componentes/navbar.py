import reflex as rx
"""
def navbar():
    return rx.box(
        rx.hstack(
            rx.heading("Mi App Reflex", size="4"),
            rx.spacer(),  # Añade espacio entre elementos
            rx.hstack(  # Botones a la derecha (opcional)
                rx.link("Inicio", href="/"),
                rx.link("Galería", href="/imagen"),
                spacing="4",
            ),
            justify="between",  # Valor correcto
            padding="1em",
            bg="blue.800",
            color="white",
            width="100%",
        ),
        position="sticky",
        top="0",
        z_index="999",
    )"""